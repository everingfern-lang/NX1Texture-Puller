@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0nx1_asset_menu.ps1"
if errorlevel 1 (
  echo.
  echo ============================================================
  echo NX1 ASSET MENU ERROR
  echo ============================================================
  echo Copy the error above and send it to the project maintainer.
  pause
)
endlocal
