$ErrorActionPreference = "Stop"
$script:SettingsFile = Join-Path $PSScriptRoot "nx1_paths.json"
$script:Exe = Join-Path $PSScriptRoot "build-win\Release\NX1ImagePuller.exe"

function Pause-NX1 {
    Write-Host ""
    [void](Read-Host "Press Enter to continue")
}

function Ensure-Exe {
    if (Test-Path $script:Exe) { return }
    Clear-Host
    Write-Host "NX1ImagePuller.exe has not been built yet." -ForegroundColor Yellow
    Write-Host "Running the portable builder..."
    & (Join-Path $PSScriptRoot "build_windows_fixed.bat")
    if (-not (Test-Path $script:Exe)) {
        throw "The build did not create NX1ImagePuller.exe."
    }
}

function Select-Folder([string]$Description, [string]$InitialPath = "") {
    try {
        Add-Type -AssemblyName System.Windows.Forms
        $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
        $dialog.Description = $Description
        $dialog.ShowNewFolderButton = $true
        if ($InitialPath -and (Test-Path $InitialPath)) {
            $dialog.SelectedPath = $InitialPath
        }
        $result = $dialog.ShowDialog()
        if ($result -eq [System.Windows.Forms.DialogResult]::OK) {
            return $dialog.SelectedPath
        }
    } catch {
        # Fall through to text entry if the folder dialog is unavailable.
    }

    Write-Host ""
    Write-Host $Description -ForegroundColor Cyan
    $typed = Read-Host "Paste a folder path, or leave blank to cancel"
    if ([string]::IsNullOrWhiteSpace($typed)) { return $null }
    return $typed.Trim('"')
}

function Save-Settings {
    $obj = [ordered]@{
        GameRoot   = $script:GameRoot
        OutputBase = $script:OutputBase
    }
    $obj | ConvertTo-Json | Set-Content -LiteralPath $script:SettingsFile -Encoding UTF8
}

function Load-Settings {
    $script:GameRoot = ""
    $script:OutputBase = ""

    if (Test-Path $script:SettingsFile) {
        try {
            $saved = Get-Content -LiteralPath $script:SettingsFile -Raw | ConvertFrom-Json
            if ($saved.GameRoot)   { $script:GameRoot = [string]$saved.GameRoot }
            if ($saved.OutputBase) { $script:OutputBase = [string]$saved.OutputBase }
        } catch {}
    }

    if (-not $script:OutputBase) {
        $script:OutputBase = Join-Path ([Environment]::GetFolderPath("Desktop")) "NX1_Extracted"
    }
}

function Choose-GameFolder {
    $picked = Select-Folder "Choose the NX1 GAME folder. You can switch to any drive here." $script:GameRoot
    if (-not $picked) { return $false }

    if (-not (Test-Path -LiteralPath $picked -PathType Container)) {
        Write-Host "That folder does not exist." -ForegroundColor Red
        Pause-NX1
        return $false
    }

    $ff = Get-ChildItem -LiteralPath $picked -Recurse -File -ErrorAction SilentlyContinue |
          Where-Object { $_.Extension -in ".ff", ".ffm" } |
          Select-Object -First 1
    if (-not $ff) {
        Write-Host ""
        Write-Host "That folder does not appear to contain NX1 .ff/.ffm files." -ForegroundColor Yellow
        Write-Host "You can still use it, but double-check that you selected the correct NX1 folder."
        $answer = Read-Host "Save it anyway? (Y/N)"
        if ($answer -notmatch '^[Yy]') { return $false }
    }

    $script:GameRoot = $picked
    Save-Settings
    return $true
}

function Choose-OutputFolder {
    $picked = Select-Folder "Choose where extracted NX1 files should be saved. This can be on ANY drive." $script:OutputBase
    if (-not $picked) { return $false }

    New-Item -ItemType Directory -Force -Path $picked | Out-Null
    $script:OutputBase = $picked
    Save-Settings
    return $true
}

function Ensure-Paths {
    if (-not $script:GameRoot -or -not (Test-Path -LiteralPath $script:GameRoot)) {
        Clear-Host
        Write-Host "First-time setup: choose your NX1 game folder." -ForegroundColor Cyan
        if (-not (Choose-GameFolder)) {
            throw "No NX1 game folder was selected."
        }
    }
    if (-not $script:OutputBase) {
        if (-not (Choose-OutputFolder)) {
            throw "No output folder was selected."
        }
    }
    New-Item -ItemType Directory -Force -Path $script:OutputBase | Out-Null
}

function Map-Output { return (Join-Path $script:OutputBase "NX1_Map_Assets") }
function Image-Output { return (Join-Path $script:OutputBase "NX1_Images") }

function Get-MapList([bool]$MultiplayerOnly) {
    $mode = if ($MultiplayerOnly) { "--list-mp-maps" } else { "--list-maps" }
    return @(& $script:Exe $mode $script:GameRoot | Where-Object { $_ -and $_.Trim() })
}

function Pick-Map([bool]$MultiplayerOnly) {
    $maps = @(Get-MapList $MultiplayerOnly)
    if ($maps.Count -eq 0) {
        Write-Host "No maps were found." -ForegroundColor Red
        Pause-NX1
        return
    }

    Clear-Host
    Write-Host "Available maps" -ForegroundColor Cyan
    Write-Host "------------------------------------------------------------"
    for ($i = 0; $i -lt $maps.Count; $i++) {
        Write-Host (" {0,3}. {1}" -f ($i + 1), $maps[$i])
    }
    Write-Host ""
    $choice = Read-Host "Type a map number, or Q to go back"
    if ($choice -match '^[Qq]$') { return }

    $n = 0
    if (-not [int]::TryParse($choice, [ref]$n) -or $n -lt 1 -or $n -gt $maps.Count) {
        Write-Host "Invalid map number." -ForegroundColor Red
        Pause-NX1
        return
    }

    $map = $maps[$n - 1]
    $out = Map-Output
    New-Item -ItemType Directory -Force -Path $out | Out-Null
    & $script:Exe "--map" $map $script:GameRoot $out
    Pause-NX1
}

function Pull-FullGame {
    $out = Image-Output
    New-Item -ItemType Directory -Force -Path $out | Out-Null
    & $script:Exe $script:GameRoot $out
    Write-Host ""
    Write-Host "Multiplayer weapon textures:" -ForegroundColor Cyan
    Write-Host "  $(Join-Path $out 'MULTIPLAYER_WEAPONS_BY_GUN')"
    Pause-NX1
}

function Show-Locations {
    Clear-Host
    Write-Host "Current NX1 locations" -ForegroundColor Cyan
    Write-Host "------------------------------------------------------------"
    Write-Host "Game folder:"
    Write-Host "  $script:GameRoot"
    Write-Host ""
    Write-Host "Output base:"
    Write-Host "  $script:OutputBase"
    Write-Host ""
    Write-Host "Map output:"
    Write-Host "  $(Map-Output)"
    Write-Host ""
    Write-Host "Full-game / weapon output:"
    Write-Host "  $(Image-Output)"
    Pause-NX1
}

function Open-Output {
    New-Item -ItemType Directory -Force -Path $script:OutputBase | Out-Null
    Start-Process explorer.exe $script:OutputBase
}

function Reset-Settings {
    if (Test-Path $script:SettingsFile) {
        Remove-Item -LiteralPath $script:SettingsFile -Force
    }
    Load-Settings
    Clear-Host
    Write-Host "Saved drive/folder settings were reset." -ForegroundColor Green
    Write-Host "The next menu action will ask you to choose locations again."
    Pause-NX1
}

Ensure-Exe
Load-Settings
Ensure-Paths

while ($true) {
    Clear-Host
    Write-Host "============================================================"
    Write-Host "       NX1 IMAGE / MAP / MULTIPLAYER WEAPON PULLER"
    Write-Host "                    v0.6.0 PORTABLE"
    Write-Host "============================================================"
    Write-Host ""
    Write-Host "GAME   : $script:GameRoot"
    Write-Host "OUTPUT : $script:OutputBase"
    Write-Host ""
    Write-Host "  1. Pull EVERY multiplayer map texture"
    Write-Host "  2. Pick ONE multiplayer map"
    Write-Host "  3. Pull EVERY map texture"
    Write-Host "  4. Pick ONE map from all maps"
    Write-Host "  5. Pull full game + multiplayer weapon textures"
    Write-Host ""
    Write-Host "  6. SWITCH NX1 GAME DRIVE / FOLDER"
    Write-Host "  7. SWITCH OUTPUT DRIVE / FOLDER"
    Write-Host "  8. Show current locations"
    Write-Host "  9. Open output folder"
    Write-Host "  R. Reset saved locations"
    Write-Host "  0. Exit"
    Write-Host ""
    $choice = Read-Host "Choose an option"

    switch ($choice.ToUpperInvariant()) {
        "1" {
            $out = Map-Output
            New-Item -ItemType Directory -Force -Path $out | Out-Null
            & $script:Exe "--all-mp-maps" $script:GameRoot $out
            Pause-NX1
        }
        "2" { Pick-Map $true }
        "3" {
            $out = Map-Output
            New-Item -ItemType Directory -Force -Path $out | Out-Null
            & $script:Exe "--all-maps" $script:GameRoot $out
            Pause-NX1
        }
        "4" { Pick-Map $false }
        "5" { Pull-FullGame }
        "6" { [void](Choose-GameFolder) }
        "7" { [void](Choose-OutputFolder) }
        "8" { Show-Locations }
        "9" { Open-Output }
        "R" { Reset-Settings; Ensure-Paths }
        "0" { break }
        default {
            Write-Host "Choose 0-9 or R." -ForegroundColor Yellow
            Start-Sleep -Milliseconds 900
        }
    }
}
