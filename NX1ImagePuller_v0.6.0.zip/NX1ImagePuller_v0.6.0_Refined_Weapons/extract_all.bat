@echo off
setlocal
cd /d "%~dp0"

if "%~1"=="" (
  echo Usage:
  echo   extract_all.bat "F:\path\to\NX1" [output-folder]
  echo.
  echo Example:
  echo   extract_all.bat "F:\Xbox 360 emulation\NX!\NX1" "F:\NX1_Images"
  exit /b 1
)

set "EXE=%~dp0build-win\Release\NX1ImagePuller.exe"
if not exist "%EXE%" (
  echo NX1ImagePuller.exe has not been built yet.
  echo Run build_windows_fixed.bat first.
  pause
  exit /b 1
)

set "OUT=%~2"
if "%OUT%"=="" set "OUT=%~dp0NX1_Images"

"%EXE%" "%~1" "%OUT%"
set "RC=%ERRORLEVEL%"

if not "%RC%"=="0" (
  echo.
  echo ============================================================
  echo NX1ImagePuller exited with code %RC%
  echo ============================================================
  echo Copy the output above and send it to ChatGPT.
  pause
)

exit /b %RC%
