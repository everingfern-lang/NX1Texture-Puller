@echo off
echo This portable release no longer hardcodes a drive letter.
echo.
echo Open NX1_ASSET_MENU.bat and choose:
echo   1. Pull EVERY multiplayer map texture
echo.
pause
call "%~dp0NX1_ASSET_MENU.bat"
