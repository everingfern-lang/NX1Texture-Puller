#include <algorithm>
#include <array>
#include <cctype>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <optional>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <vector>

#include <zlib.h>

namespace fs = std::filesystem;

namespace
{
constexpr std::size_t kAuthChunkSize = 0x2000;
constexpr unsigned kDataChunksPerAuthGroup = 256;
constexpr std::size_t kGfxImageSize = 0x70;
constexpr std::size_t kNamePointerOffset = 0x6C;
constexpr std::size_t kFormatOffset = 0x34;
constexpr std::size_t kStreamDataOffset = 0x4C;

struct FormatInfo
{
    const char* name;
    int blockSize;      // 4 for block compressed, 1 for 32-bit uncompressed.
    int texelPitch;     // bytes per compression block / pixel.
    std::uint32_t fourCC;
    bool uncompressed32;
    bool hasAlpha;
};

constexpr std::uint32_t FourCC(char a, char b, char c, char d)
{
    return std::uint32_t(std::uint8_t(a)) |
           (std::uint32_t(std::uint8_t(b)) << 8) |
           (std::uint32_t(std::uint8_t(c)) << 16) |
           (std::uint32_t(std::uint8_t(d)) << 24);
}

// Formats observed in NX1's real mp_nx_meteor.ffm plus Astral's NX1MAPPER mappings.
// 0x08000152 behaves as an alternate DXT1/BC1 encoding in the streamed data.
// 0x2800017B / 0x05B4017B are DXT5A-style single-channel 8-byte blocks and export as ATI1/BC4.
const std::unordered_map<std::uint32_t, FormatInfo> kFormats = {
    {0x1A200152u, {"BC1", 4, 8,  FourCC('D','X','T','1'), false, false}},
    {0x08000152u, {"BC1_ALT", 4, 8, FourCC('D','X','T','1'), false, false}},
    {0x1A200153u, {"BC2", 4, 16, FourCC('D','X','T','3'), false, true}},
    {0x1A200154u, {"BC3", 4, 16, FourCC('D','X','T','5'), false, true}},
    {0x1A200171u, {"BC5", 4, 16, FourCC('A','T','I','2'), false, false}},
    {0x2800017Bu, {"BC4", 4, 8, FourCC('A','T','I','1'), false, false}},
    {0x05B4017Bu, {"BC4_ALT", 4, 8, FourCC('A','T','I','1'), false, false}},
    {0x18280186u, {"A8R8G8B8", 1, 4, 0, true, true}},
    {0x28280186u, {"X8R8G8B8", 1, 4, 0, true, false}},
};

std::uint16_t be16(const std::vector<std::uint8_t>& b, std::size_t p)
{
    if (p + 2 > b.size()) throw std::runtime_error("unexpected end of buffer");
    return (std::uint16_t(b[p]) << 8) | std::uint16_t(b[p + 1]);
}

std::uint32_t be32(const std::vector<std::uint8_t>& b, std::size_t p)
{
    if (p + 4 > b.size()) throw std::runtime_error("unexpected end of buffer");
    return (std::uint32_t(b[p]) << 24) | (std::uint32_t(b[p + 1]) << 16) |
           (std::uint32_t(b[p + 2]) << 8) | std::uint32_t(b[p + 3]);
}

void put32le(std::vector<std::uint8_t>& out, std::size_t p, std::uint32_t v)
{
    out[p + 0] = std::uint8_t(v & 0xFF);
    out[p + 1] = std::uint8_t((v >> 8) & 0xFF);
    out[p + 2] = std::uint8_t((v >> 16) & 0xFF);
    out[p + 3] = std::uint8_t((v >> 24) & 0xFF);
}

std::vector<std::uint8_t> readAll(const fs::path& p)
{
    std::ifstream f(p, std::ios::binary);
    if (!f) throw std::runtime_error("could not open: " + p.string());
    f.seekg(0, std::ios::end);
    const auto end = f.tellg();
    if (end < 0) throw std::runtime_error("could not get file size: " + p.string());
    f.seekg(0, std::ios::beg);
    std::vector<std::uint8_t> data(static_cast<std::size_t>(end));
    if (!data.empty() && !f.read(reinterpret_cast<char*>(data.data()), static_cast<std::streamsize>(data.size())))
        throw std::runtime_error("could not read: " + p.string());
    return data;
}

std::vector<std::uint8_t> inflateStream(const std::uint8_t* src, std::size_t size, std::size_t reserveHint = 0)
{
    z_stream zs{};
    if (inflateInit(&zs) != Z_OK) throw std::runtime_error("zlib inflateInit failed");

    std::vector<std::uint8_t> out;
    if (reserveHint) out.reserve(reserveHint);
    // Keep the 1 MiB inflate scratch buffer on the heap. Windows/MSVC's default
    // thread stack is commonly ~1 MiB, so a 1 MiB local array can stack-overflow
    // before C++ exception handling has a chance to report an error.
    std::vector<std::uint8_t> tmp(1u << 20);
    std::size_t inputPos = 0;
    int rc = Z_OK;

    while (rc != Z_STREAM_END)
    {
        if (zs.avail_in == 0 && inputPos < size)
        {
            const auto n = std::min<std::size_t>(size - inputPos, std::numeric_limits<uInt>::max());
            zs.next_in = const_cast<Bytef*>(reinterpret_cast<const Bytef*>(src + inputPos));
            zs.avail_in = static_cast<uInt>(n);
            inputPos += n;
        }

        zs.next_out = reinterpret_cast<Bytef*>(tmp.data());
        zs.avail_out = static_cast<uInt>(tmp.size());
        rc = inflate(&zs, Z_NO_FLUSH);
        const auto made = tmp.size() - zs.avail_out;
        out.insert(out.end(), tmp.data(), tmp.data() + made);

        if (rc == Z_STREAM_END) break;
        if (rc != Z_OK)
        {
            inflateEnd(&zs);
            std::ostringstream ss;
            ss << "zlib decompression failed (code " << rc << ")";
            throw std::runtime_error(ss.str());
        }
        if (made == 0 && zs.avail_in == 0 && inputPos >= size)
        {
            inflateEnd(&zs);
            throw std::runtime_error("zlib stream ended unexpectedly");
        }
    }

    inflateEnd(&zs);
    return out;
}

struct StreamRecord
{
    std::uint32_t file = 0;
    std::uint32_t start = 0;
    std::uint32_t end = 0;
};

struct FastFile
{
    bool signedFile = false;
    std::uint32_t version = 0;
    std::size_t payloadOffset = 0;
    std::vector<StreamRecord> streams;
};

FastFile parseFastFileHeader(const std::vector<std::uint8_t>& file)
{
    if (file.size() < 0x26) throw std::runtime_error("file is too small to be an NX1 FastFile");

    std::string magic(reinterpret_cast<const char*>(file.data()), 8);
    if (magic != "NXff0100" && magic != "NXffu100")
        throw std::runtime_error("not an NX1 FastFile (expected NXff0100/NXffu100)");

    FastFile ff;
    ff.signedFile = magic == "NXff0100";
    ff.version = be32(file, 0x08);
    const std::uint32_t streamCount = be32(file, 0x1A);
    if (streamCount > 4'000'000u) throw std::runtime_error("implausible stream table count");

    const std::uint64_t tableStart = 0x1Eull;
    const std::uint64_t tableEnd = tableStart + std::uint64_t(streamCount) * 12ull;
    if (tableEnd + 8 > file.size()) throw std::runtime_error("stream table runs past end of file");

    ff.streams.reserve(streamCount);
    for (std::uint32_t i = 0; i < streamCount; ++i)
    {
        const std::size_t p = static_cast<std::size_t>(tableStart + std::uint64_t(i) * 12ull);
        ff.streams.push_back({be32(file, p), be32(file, p + 4), be32(file, p + 8)});
    }
    ff.payloadOffset = static_cast<std::size_t>(tableEnd + 8);
    return ff;
}

std::vector<std::uint8_t> extractMainCompressed(const std::vector<std::uint8_t>& file, const FastFile& ff)
{
    if (!ff.signedFile)
    {
        if (ff.payloadOffset >= file.size()) throw std::runtime_error("missing unsigned zlib stream");
        return std::vector<std::uint8_t>(file.begin() + static_cast<std::ptrdiff_t>(ff.payloadOffset), file.end());
    }

    if (ff.payloadOffset + kAuthChunkSize > file.size()) throw std::runtime_error("signed auth header is truncated");
    const std::string inner(reinterpret_cast<const char*>(file.data() + ff.payloadOffset), 8);
    if (inner != "NXffs100") throw std::runtime_error("signed file is missing NXffs100 auth header");

    std::vector<std::uint8_t> compressed;
    compressed.reserve(file.size() - ff.payloadOffset);
    std::size_t p = ff.payloadOffset + kAuthChunkSize;
    while (p < file.size())
    {
        // One group-hash chunk, followed by up to 256 authenticated data chunks.
        p += std::min<std::size_t>(kAuthChunkSize, file.size() - p);
        for (unsigned i = 0; i < kDataChunksPerAuthGroup && p < file.size(); ++i)
        {
            const auto n = std::min<std::size_t>(kAuthChunkSize, file.size() - p);
            compressed.insert(compressed.end(), file.begin() + static_cast<std::ptrdiff_t>(p),
                              file.begin() + static_cast<std::ptrdiff_t>(p + n));
            p += n;
        }
    }
    if (compressed.size() < 2 || compressed[0] != 0x78)
        throw std::runtime_error("authenticated chunks did not reconstruct a zlib stream");
    return compressed;
}

struct MipInfo
{
    std::uint16_t width = 0;
    std::uint16_t height = 0;
    std::uint32_t packed = 0;
    std::uint32_t cumulativeBytes = 0;
    std::uint32_t partBytes = 0;
};

struct ImageHeader
{
    std::size_t zoneOffset = 0;
    std::uint32_t format = 0;
    std::uint8_t mapType = 0;
    std::uint8_t semantic = 0;
    std::uint8_t category = 0;
    std::uint32_t namePointer = 0;
    std::array<MipInfo, 4> mips{};
    std::string name;
};

bool printable(std::uint8_t c)
{
    return c >= 32 && c <= 126;
}

std::optional<std::string> readCString(const std::vector<std::uint8_t>& d, std::size_t start, std::size_t maxLen = 300)
{
    if (start >= d.size()) return std::nullopt;
    std::string s;
    for (std::size_t i = 0; i < maxLen && start + i < d.size(); ++i)
    {
        const auto c = d[start + i];
        if (c == 0) return s.empty() ? std::nullopt : std::optional<std::string>(s);
        if (!printable(c)) return std::nullopt;
        s.push_back(static_cast<char>(c));
    }
    return std::nullopt;
}

std::optional<std::string> findPreviousCString(const std::vector<std::uint8_t>& d, std::size_t headerOffset, std::size_t window = 160)
{
    if (headerOffset == 0) return std::nullopt;
    const std::size_t lo = headerOffset > window ? headerOffset - window : 0;

    // Search closest-to-header terminated printable string first.
    for (std::size_t end = headerOffset; end-- > lo; )
    {
        if (d[end] != 0) continue;
        if (end == 0) continue;
        std::size_t start = end;
        while (start > lo && printable(d[start - 1])) --start;
        if (end > start && end - start >= 3 && end - start <= 128)
            return std::string(reinterpret_cast<const char*>(d.data() + start), end - start);
    }
    return std::nullopt;
}

bool parseImageCandidate(const std::vector<std::uint8_t>& zone, std::size_t off, ImageHeader& out)
{
    if (off + kGfxImageSize > zone.size()) return false;
    const auto fmt = be32(zone, off + kFormatOffset);
    if (kFormats.find(fmt) == kFormats.end()) return false;

    const auto mapType = zone[off + 0x38];
    const auto semantic = zone[off + 0x39];
    const auto category = zone[off + 0x3A];
    if (!(mapType == 3 || mapType == 5)) return false;
    if (category != 3) return false; // All real NX1 streamed images observed use category 3.

    const auto namePtr = be32(zone, off + kNamePointerOffset);
    if (namePtr == 0) return false;

    std::uint32_t previous = 0;
    bool reachedEmpty = false;
    bool any = false;
    std::array<MipInfo,4> mips{};
    for (int i = 0; i < 4; ++i)
    {
        const auto p = off + kStreamDataOffset + std::size_t(i) * 8;
        MipInfo m;
        m.width = be16(zone, p);
        m.height = be16(zone, p + 2);
        m.packed = be32(zone, p + 4);
        m.cumulativeBytes = m.packed & 0x03FFFFFFu;

        const bool empty = m.width == 0 && m.height == 0 && m.cumulativeBytes == 0;
        if (empty)
        {
            reachedEmpty = true;
            mips[i] = m;
            continue;
        }
        if (reachedEmpty || m.width == 0 || m.height == 0 || m.cumulativeBytes == 0) return false;
        if (m.width > 16384 || m.height > 16384) return false;
        if (m.cumulativeBytes <= previous) return false;
        m.partBytes = m.cumulativeBytes - previous;
        previous = m.cumulativeBytes;
        any = true;
        mips[i] = m;
    }
    if (!any) return false;

    out.zoneOffset = off;
    out.format = fmt;
    out.mapType = mapType;
    out.semantic = semantic;
    out.category = category;
    out.namePointer = namePtr;
    out.mips = mips;
    return true;
}

std::vector<ImageHeader> scanImageHeaders(const std::vector<std::uint8_t>& zone)
{
    std::vector<ImageHeader> images;
    if (zone.size() < kGfxImageSize) return images;

    for (std::size_t off = 0; off + kGfxImageSize <= zone.size(); ++off)
    {
        ImageHeader img;
        if (!parseImageCandidate(zone, off, img)) continue;

        if (img.namePointer == 0xFFFFFFFFu)
        {
            if (auto s = readCString(zone, off + kGfxImageSize)) img.name = *s;
        }
        else
        {
            if (auto s = findPreviousCString(zone, off)) img.name = *s;
        }
        images.push_back(std::move(img));
    }

    return images;
}

int xgAddress2DTiledX(int offset, int width, int texelPitch)
{
    const int alignedWidth = (width + 31) & ~31;
    const int logBpp = (texelPitch >> 2) + ((texelPitch >> 1) >> (texelPitch >> 2));
    const int offsetB = offset << logBpp;
    const int offsetT = ((offsetB & ~4095) >> 3) + ((offsetB & 1792) >> 2) + (offsetB & 63);
    const int offsetM = offsetT >> (7 + logBpp);
    const int macroX = (offsetM % (alignedWidth >> 5)) << 2;
    const int tile = (((offsetT >> (5 + logBpp)) & 2) + (offsetB >> 6)) & 3;
    const int macro = (macroX + tile) << 3;
    const int micro = ((((offsetT >> 1) & ~15) + (offsetT & 15)) & ((texelPitch << 3) - 1)) >> logBpp;
    return macro + micro;
}

int xgAddress2DTiledY(int offset, int width, int texelPitch)
{
    const int alignedWidth = (width + 31) & ~31;
    const int logBpp = (texelPitch >> 2) + ((texelPitch >> 1) >> (texelPitch >> 2));
    const int offsetB = offset << logBpp;
    const int offsetT = ((offsetB & ~4095) >> 3) + ((offsetB & 1792) >> 2) + (offsetB & 63);
    const int offsetM = offsetT >> (7 + logBpp);
    const int macroY = (offsetM / (alignedWidth >> 5)) << 2;
    const int tile = ((offsetT >> (6 + logBpp)) & 1) + ((offsetB & 2048) >> 10);
    const int macro = (macroY + tile) << 3;
    const int micro = ((((offsetT & (((texelPitch << 6) - 1) & ~31)) + ((offsetT & 15) << 1)) >> (3 + logBpp)) & ~1);
    return macro + micro + ((offsetT & 16) >> 4);
}

void swap16(std::vector<std::uint8_t>& data)
{
    for (std::size_t i = 0; i + 1 < data.size(); i += 2) std::swap(data[i], data[i + 1]);
}

std::vector<std::uint8_t> untile360(const std::vector<std::uint8_t>& tiled, int width, int height, const FormatInfo& fmt)
{
    const int bw = (width + fmt.blockSize - 1) / fmt.blockSize;
    const int bh = (height + fmt.blockSize - 1) / fmt.blockSize;
    if (bw <= 0 || bh <= 0) throw std::runtime_error("invalid texture dimensions");

    const std::size_t logicalBytes = std::size_t(bw) * std::size_t(bh) * std::size_t(fmt.texelPitch);
    std::vector<std::uint8_t> linear(logicalBytes, 0);

    // Iterate the complete padded/tiled source, not merely logical blocks. This fixes the
    // common 32/64-pixel case that breaks if Xbox 360 padding columns are ignored.
    const std::size_t sourceBlocks = tiled.size() / static_cast<std::size_t>(fmt.texelPitch);
    for (std::size_t blockOffset = 0; blockOffset < sourceBlocks; ++blockOffset)
    {
        if (blockOffset > static_cast<std::size_t>(std::numeric_limits<int>::max())) break;
        const int x = xgAddress2DTiledX(static_cast<int>(blockOffset), bw, fmt.texelPitch);
        const int y = xgAddress2DTiledY(static_cast<int>(blockOffset), bw, fmt.texelPitch);
        if (x < 0 || y < 0 || x >= bw || y >= bh) continue;

        const std::size_t src = blockOffset * static_cast<std::size_t>(fmt.texelPitch);
        const std::size_t dst = (std::size_t(y) * std::size_t(bw) + std::size_t(x)) * static_cast<std::size_t>(fmt.texelPitch);
        if (src + fmt.texelPitch <= tiled.size() && dst + fmt.texelPitch <= linear.size())
            std::memcpy(linear.data() + dst, tiled.data() + src, static_cast<std::size_t>(fmt.texelPitch));
    }
    return linear;
}

std::vector<std::uint8_t> makeDDSHeader(int width, int height, const FormatInfo& fmt)
{
    std::vector<std::uint8_t> h(128, 0);
    h[0] = 'D'; h[1] = 'D'; h[2] = 'S'; h[3] = ' ';
    put32le(h, 4, 124); // DDS_HEADER size

    constexpr std::uint32_t DDSD_CAPS = 0x1;
    constexpr std::uint32_t DDSD_HEIGHT = 0x2;
    constexpr std::uint32_t DDSD_WIDTH = 0x4;
    constexpr std::uint32_t DDSD_PITCH = 0x8;
    constexpr std::uint32_t DDSD_PIXELFORMAT = 0x1000;
    constexpr std::uint32_t DDSD_LINEARSIZE = 0x80000;

    const std::uint32_t flags = DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH | DDSD_PIXELFORMAT |
                                (fmt.uncompressed32 ? DDSD_PITCH : DDSD_LINEARSIZE);
    put32le(h, 8, flags);
    put32le(h, 12, static_cast<std::uint32_t>(height));
    put32le(h, 16, static_cast<std::uint32_t>(width));

    if (fmt.uncompressed32)
        put32le(h, 20, static_cast<std::uint32_t>(width * 4));
    else
    {
        const int bw = (width + 3) / 4;
        const int bh = (height + 3) / 4;
        put32le(h, 20, static_cast<std::uint32_t>(bw * bh * fmt.texelPitch));
    }

    put32le(h, 76, 32); // DDS_PIXELFORMAT size
    if (!fmt.uncompressed32)
    {
        put32le(h, 80, 0x4); // DDPF_FOURCC
        put32le(h, 84, fmt.fourCC);
    }
    else
    {
        put32le(h, 80, fmt.hasAlpha ? 0x41u : 0x40u); // DDPF_RGB | optional alpha pixels
        put32le(h, 88, 32);
        put32le(h, 92, 0x00FF0000u); // R
        put32le(h, 96, 0x0000FF00u); // G
        put32le(h, 100, 0x000000FFu); // B
        put32le(h, 104, fmt.hasAlpha ? 0xFF000000u : 0u); // A
    }
    put32le(h, 108, 0x1000); // DDSCAPS_TEXTURE
    return h;
}

std::string sanitizeFileName(std::string s)
{
    for (char& c : s)
    {
        const unsigned char u = static_cast<unsigned char>(c);
        if (u < 32 || c == '<' || c == '>' || c == ':' || c == '"' || c == '/' || c == '\\' || c == '|' || c == '?' || c == '*') c = '_';
    }
    while (!s.empty() && (s.back() == ' ' || s.back() == '.')) s.pop_back();
    if (s.empty()) s = "unnamed";
    if (s.size() > 180) s.resize(180);
    return s;
}

std::string csvEscape(const std::string& s)
{
    if (s.find_first_of(",\"\r\n") == std::string::npos) return s;
    std::string x = "\"";
    for (char c : s) { if (c == '"') x += '"'; x += c; }
    x += '"';
    return x;
}

bool isUiTextureName(const std::string& name)
{
    std::string s = name;
    std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c){ return static_cast<char>(std::tolower(c)); });
    const char* words[] = {
        "cardicon", "cardtitle", "award_", "hud", "menu", "ui_",
        "rank_", "prestige", "emblem", "challenge", "scoreboard"
    };
    for (auto w : words)
        if (s.find(w) != std::string::npos) return true;
    return false;
}

bool isCharacterTextureName(const std::string& name)
{
    std::string s = name;
    std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c){ return static_cast<char>(std::tolower(c)); });

    const char* strong[] = {
        "char_", "character", "view_hands", "_hands_", "head_", "_head_",
        "hood_", "_hood_", "upperbody", "lowerbody", "_body_", "ghillie",
        "_face_", "facial", "_arm_", "_arms_", "_leg_", "_legs_"
    };
    for (auto w : strong)
        if (s.find(w) != std::string::npos) return true;

    // Team/character prefixes combined with clothing/loadout terms.
    const bool actorPrefix =
        s.rfind("ally_", 0) == 0 || s.rfind("enemy_", 0) == 0 ||
        s.rfind("opforce_", 0) == 0 || s.rfind("marine_", 0) == 0;
    if (actorPrefix &&
        (s.find("loadout") != std::string::npos || s.find("uniform") != std::string::npos ||
         s.find("gear") != std::string::npos || s.find("vest") != std::string::npos))
        return true;

    return false;
}

bool containsAssetToken(const std::string& s, const std::string& token)
{
    std::size_t pos = 0;
    while ((pos = s.find(token, pos)) != std::string::npos)
    {
        const bool leftOk = (pos == 0) || !std::isalnum(static_cast<unsigned char>(s[pos - 1]));
        const std::size_t end = pos + token.size();
        const bool rightOk = (end >= s.size()) || !std::isalnum(static_cast<unsigned char>(s[end]));
        if (leftOk && rightOk) return true;
        ++pos;
    }
    return false;
}

struct WeaponDetection
{
    bool accepted = false;
    std::string weapon;
    std::string matchType;
    std::string confidence;
};

std::string upperFolderName(std::string s)
{
    for (char& c : s)
    {
        if (std::isalnum(static_cast<unsigned char>(c)))
            c = static_cast<char>(std::toupper(static_cast<unsigned char>(c)));
        else
            c = '_';
    }
    std::string out;
    bool lastUnderscore = false;
    for (char c : s)
    {
        if (c == '_')
        {
            if (!lastUnderscore) out.push_back(c);
            lastUnderscore = true;
        }
        else
        {
            out.push_back(c);
            lastUnderscore = false;
        }
    }
    while (!out.empty() && out.front() == '_') out.erase(out.begin());
    while (!out.empty() && out.back() == '_') out.pop_back();
    return out.empty() ? "UNKNOWN_WEAPON" : out;
}

bool hasWeaponMaterialCue(const std::string& s)
{
    const char* cues[] = {
        "_col", "_color", "_diff", "_diffuse", "_nml", "_norm", "_normal",
        "_spec", "_spc", "_gloss", "_ao", "_detail", "_detailmap",
        "_camo", "_mask", "_metal", "_rough", "_emit"
    };
    for (auto c : cues)
        if (s.find(c) != std::string::npos) return true;
    return false;
}

bool isSharedAttachmentName(const std::string& s)
{
    const char* terms[] = {
        "scope", "optic", "reticle", "reddot", "red_dot", "acog", "holo",
        "silencer", "suppressor", "magazine", "foregrip", "grip",
        "muzzle", "rail", "attachment"
    };
    for (auto t : terms)
        if (containsAssetToken(s, t) || s.find(std::string("_") + t + "_") != std::string::npos)
            return true;
    return false;
}

WeaponDetection detectWeaponTexture(const std::string& name)
{
    WeaponDetection d;
    if (isUiTextureName(name) || isCharacterTextureName(name)) return d;

    std::string s = name;
    std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c){ return static_cast<char>(std::tolower(c)); });

    // Canonical gun names. Matching is token-boundary aware, so e.g. FAL will
    // never match "falloff".
    struct Alias { const char* token; const char* canonical; };
    static const Alias aliases[] = {
        {"colt1911","COLT1911"}, {"m1911","COLT1911"},
        {"ak47","AK47"}, {"ak_47","AK47"}, {"ak74","AK74"}, {"ak_74","AK74"},
        {"m16","M16"}, {"m4a1","M4A1"}, {"acr","ACR"}, {"scar","SCAR"},
        {"famas","FAMAS"}, {"fal","FAL"}, {"tar21","TAR21"}, {"tar_21","TAR21"},
        {"cm901","CM901"}, {"mk14","MK14"}, {"m14","M14"}, {"g36c","G36C"}, {"g36","G36"},
        {"mp5","MP5"}, {"mp7","MP7"}, {"ump45","UMP45"}, {"ump_45","UMP45"},
        {"p90","P90"}, {"vector","VECTOR"}, {"miniuzi","MINIUZI"}, {"mini_uzi","MINIUZI"},
        {"fmg9","FMG9"}, {"fmg_9","FMG9"}, {"pp90m1","PP90M1"}, {"pp90","PP90M1"},
        {"mp9","MP9"}, {"skorpion","SKORPION"}, {"g18","G18"},
        {"p99","P99"}, {"usp45","USP45"}, {"usp_45","USP45"}, {"usp","USP"},
        {"glock","GLOCK"}, {"deagle","DESERT_EAGLE"}, {"desert_eagle","DESERT_EAGLE"},
        {"magnum","MAGNUM"}, {"revolver","REVOLVER"}, {"beretta","BERETTA"}, {"m9","M9"},
        {"spas12","SPAS12"}, {"spas_12","SPAS12"}, {"aa12","AA12"}, {"aa_12","AA12"},
        {"usas12","USAS12"}, {"usas_12","USAS12"}, {"striker","STRIKER"}, {"model1887","MODEL1887"},
        {"barrett","BARRETT"}, {"dragunov","DRAGUNOV"}, {"intervention","INTERVENTION"},
        {"rsass","RSASS"}, {"msr","MSR"}, {"l96","L96"}, {"m21","M21"},
        {"rpd","RPD"}, {"m60","M60"}, {"m240","M240"}, {"mg36","MG36"},
        {"mk46","MK46"}, {"pkp","PKP"},
        {"rpg7","RPG7"}, {"rpg","RPG"}, {"stinger","STINGER"}, {"javelin","JAVELIN"},
        {"at4","AT4"}, {"m320","M320"}, {"xm25","XM25"}, {"smaw","SMAW"},
        {"railgun","RAILGUN"}, {"throwing_knife","THROWING_KNIFE"}, {"combat_knife","COMBAT_KNIFE"}
    };

    auto findKnownWeapon = [&]() -> std::string
    {
        for (const auto& a : aliases)
            if (containsAssetToken(s, a.token)) return a.canonical;
        return {};
    };

    // Strongest signal: an actual weapon material/model prefix.
    const char* prefixes[] = {
        "mtl_weapon_", "~mtl_weapon_", "mtl_weap_", "mtl_wpn_",
        "weapon_", "weap_", "wpn_", "viewmodel_weapon_", "worldmodel_weapon_"
    };

    std::size_t prefixPos = std::string::npos;
    std::string usedPrefix;
    for (auto p : prefixes)
    {
        auto pos = s.find(p);
        if (pos != std::string::npos)
        {
            prefixPos = pos + std::strlen(p);
            usedPrefix = p;
            break;
        }
    }

    if (prefixPos != std::string::npos)
    {
        d.accepted = true;
        d.matchType = "explicit_weapon_prefix";
        d.confidence = "high";

        const std::string known = findKnownWeapon();
        if (!known.empty())
        {
            d.weapon = known;
            return d;
        }

        std::string id = s.substr(prefixPos);
        const char* stops[] = {
            "_col", "_color", "_diff", "_diffuse", "_nml", "_norm", "_normal",
            "_spec", "_spc", "_gloss", "_ao", "_detail", "_camo", "_mask",
            "_metal", "_rough", "_emit", "~"
        };
        std::size_t cut = id.size();
        for (auto stop : stops)
        {
            const auto p = id.find(stop);
            if (p != std::string::npos) cut = std::min(cut, p);
        }
        id.resize(cut);
        while (!id.empty() && (id.back() == '_' || id.back() == '-' || id.back() == '.')) id.pop_back();

        if (id.empty() || isSharedAttachmentName(id))
            d.weapon = "SHARED_ATTACHMENTS";
        else
            d.weapon = upperFolderName(id);
        return d;
    }

    // Shared attachments are only accepted when the name itself looks like a
    // material/texture asset. A loose word such as "scope" alone is not enough.
    if ((s.rfind("mtl_", 0) == 0 || s.rfind("~mtl_", 0) == 0) &&
        isSharedAttachmentName(s) && hasWeaponMaterialCue(s))
    {
        d.accepted = true;
        d.weapon = "SHARED_ATTACHMENTS";
        d.matchType = "shared_attachment_material";
        d.confidence = "high";
        return d;
    }

    // Known weapon ID without a weapon prefix: accept only when the asset name
    // also looks like a material texture and the ID is a real token.
    const std::string known = findKnownWeapon();
    if (!known.empty() && hasWeaponMaterialCue(s) &&
        (s.rfind("mtl_", 0) == 0 || s.rfind("~mtl_", 0) == 0 ||
         s.rfind("viewmodel_", 0) == 0 || s.rfind("worldmodel_", 0) == 0))
    {
        d.accepted = true;
        d.weapon = known;
        d.matchType = "known_weapon_material";
        d.confidence = "high";
        return d;
    }

    return d;
}

bool isWeaponTextureName(const std::string& name)
{
    return detectWeaponTexture(name).accepted;
}

std::string categoryFor(const std::string& name)
{
    std::string s = name;
    std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c){ return static_cast<char>(std::tolower(c)); });

    // Exclude UI and character art first so names such as "cardicon_ak47" or
    // "ally_sniper_head" are not mistaken for weapon surface textures.
    if (isUiTextureName(name)) return "ui";
    if (isCharacterTextureName(name)) return "characters";
    if (isWeaponTextureName(name)) return "weapons";
    if (s.find("fx_") != std::string::npos || s.find("effect") != std::string::npos ||
        s.find("smoke") != std::string::npos || s.find("fog") != std::string::npos)
        return "effects";
    return "world_and_assets";
}

struct ManifestRow
{
    std::string source;
    std::string name;
    std::string category;
    std::string format;
    std::uint32_t formatCode = 0;
    int width = 0;
    int height = 0;
    int streamIndex = -1;
    std::string output;
    std::string status;
    std::uint32_t dataCrc32 = 0;
};

bool writeDDS(const fs::path& path, int width, int height, const FormatInfo& fmt, const std::vector<std::uint8_t>& data)
{
    fs::create_directories(path.parent_path());
    std::ofstream f(path, std::ios::binary);
    if (!f) return false;
    auto header = makeDDSHeader(width, height, fmt);
    f.write(reinterpret_cast<const char*>(header.data()), static_cast<std::streamsize>(header.size()));
    f.write(reinterpret_cast<const char*>(data.data()), static_cast<std::streamsize>(data.size()));
    return bool(f);
}

std::vector<ManifestRow> processFastFile(const fs::path& input, const fs::path& outputRoot, bool verbose)
{
    std::vector<ManifestRow> rows;
    auto file = readAll(input);

    // Git LFS pointer files are not actual game data. The local game folder must contain the real bytes.
    if (file.size() < 256 && std::string(reinterpret_cast<const char*>(file.data()), file.size()).find("git-lfs") != std::string::npos)
        throw std::runtime_error("this is a Git LFS pointer, not the real FastFile; run against the local NX1 game folder");

    auto ff = parseFastFileHeader(file);
    auto compressed = extractMainCompressed(file, ff);
    auto zone = inflateStream(compressed.data(), compressed.size());
    auto images = scanImageHeaders(zone);

    if (verbose)
    {
        std::cout << "  version: " << ff.version << "\n";
        std::cout << "  stream records: " << ff.streams.size() << "\n";
        std::cout << "  image headers: " << images.size() << "\n";
    }

    const std::size_t streamGroups = ff.streams.size() / 4;
    if (ff.streams.size() % 4 != 0)
        std::cerr << "  WARNING: stream record count is not divisible by 4\n";
    if (streamGroups != images.size())
        std::cerr << "  WARNING: found " << images.size() << " image headers but " << streamGroups
                  << " four-part stream groups; ordered pairing may be incomplete\n";

    const std::size_t pairCount = std::min(streamGroups, images.size());
    const fs::path sourceDir = outputRoot / sanitizeFileName(input.stem().string());

    for (std::size_t i = 0; i < pairCount; ++i)
    {
        auto& img = images[i];
        if (img.name.empty())
        {
            std::ostringstream ss; ss << "image_" << std::setw(5) << std::setfill('0') << i;
            img.name = ss.str();
        }

        int highest = -1;
        for (int p = 3; p >= 0; --p)
            if (img.mips[p].width != 0 && img.mips[p].height != 0 && img.mips[p].partBytes != 0) { highest = p; break; }

        ManifestRow row;
        row.source = input.filename().string();
        row.name = img.name;
        row.category = categoryFor(img.name);
        row.formatCode = img.format;
        row.format = kFormats.at(img.format).name;
        row.streamIndex = static_cast<int>(i);

        if (highest < 0)
        {
            row.status = "no_streamed_pixels";
            rows.push_back(std::move(row));
            continue;
        }

        row.width = img.mips[highest].width;
        row.height = img.mips[highest].height;
        const auto recIndex = i * 4 + static_cast<std::size_t>(highest);
        if (recIndex >= ff.streams.size())
        {
            row.status = "missing_stream_record";
            rows.push_back(std::move(row));
            continue;
        }
        const auto& rec = ff.streams[recIndex];
        if (rec.start == 0 || rec.end == 0 || rec.end <= rec.start || rec.end > file.size())
        {
            row.status = "empty_or_invalid_stream_record";
            rows.push_back(std::move(row));
            continue;
        }

        try
        {
            auto pixels = inflateStream(file.data() + rec.start, rec.end - rec.start, img.mips[highest].partBytes);
            if (pixels.size() != img.mips[highest].partBytes)
            {
                std::ostringstream ss;
                ss << "stream_size_mismatch_" << pixels.size() << "_expected_" << img.mips[highest].partBytes;
                row.status = ss.str();
                rows.push_back(std::move(row));
                continue;
            }

            swap16(pixels);
            const auto& fmt = kFormats.at(img.format);
            auto linear = untile360(pixels, row.width, row.height, fmt);

            const fs::path rel = fs::path(sanitizeFileName(row.category)) / (sanitizeFileName(img.name) + ".dds");
            const fs::path outPath = sourceDir / rel;
            if (!writeDDS(outPath, row.width, row.height, fmt, linear))
                row.status = "write_failed";
            else
            {
                row.status = "ok";
                row.output = fs::relative(outPath, outputRoot).generic_string();
                row.dataCrc32 = static_cast<std::uint32_t>(::crc32(0L, reinterpret_cast<const Bytef*>(linear.data()), static_cast<uInt>(linear.size())));
            }
        }
        catch (const std::exception& e)
        {
            row.status = std::string("error:") + e.what();
        }
        rows.push_back(std::move(row));
    }

    // Preserve headers without a paired stream group in the manifest.
    for (std::size_t i = pairCount; i < images.size(); ++i)
    {
        ManifestRow row;
        row.source = input.filename().string();
        row.name = images[i].name.empty() ? ("image_" + std::to_string(i)) : images[i].name;
        row.category = categoryFor(row.name);
        row.formatCode = images[i].format;
        row.format = kFormats.at(images[i].format).name;
        row.streamIndex = static_cast<int>(i);
        row.status = "unpaired_image_header";
        rows.push_back(std::move(row));
    }
    return rows;
}

void writeManifest(const fs::path& root, const std::vector<ManifestRow>& rows)
{
    fs::create_directories(root);
    std::ofstream f(root / "images.csv");
    f << "source,name,category,format,format_code,width,height,stream_index,data_crc32,output,status\n";
    for (const auto& r : rows)
    {
        f << csvEscape(r.source) << ',' << csvEscape(r.name) << ',' << csvEscape(r.category) << ','
          << csvEscape(r.format) << ",0x" << std::hex << std::setw(8) << std::setfill('0') << r.formatCode
          << std::dec << std::setfill(' ') << ',' << r.width << ',' << r.height << ',' << r.streamIndex << ','
          << "0x" << std::hex << std::setw(8) << std::setfill('0') << r.dataCrc32 << std::dec << std::setfill(' ') << ','
          << csvEscape(r.output) << ',' << csvEscape(r.status) << "\n";
    }
}

void writeUniqueManifest(const fs::path& root, const std::vector<ManifestRow>& rows)
{
    struct Key
    {
        std::string format;
        int width;
        int height;
        std::uint32_t crc;
        bool operator<(const Key& o) const
        {
            if (format != o.format) return format < o.format;
            if (width != o.width) return width < o.width;
            if (height != o.height) return height < o.height;
            return crc < o.crc;
        }
    };

    std::map<Key, const ManifestRow*> first;
    std::map<Key, std::size_t> counts;
    for (const auto& r : rows)
    {
        if (r.status != "ok") continue;
        Key k{r.format, r.width, r.height, r.dataCrc32};
        counts[k]++;
        if (!first.count(k)) first[k] = &r;
    }

    std::ofstream f(root / "unique_images.csv");
    f << "name,category,format,width,height,data_crc32,occurrences,first_source,output\n";
    for (const auto& [k, row] : first)
    {
        f << csvEscape(row->name) << ',' << csvEscape(row->category) << ',' << csvEscape(row->format) << ','
          << row->width << ',' << row->height << ",0x" << std::hex << std::setw(8) << std::setfill('0') << row->dataCrc32
          << std::dec << std::setfill(' ') << ',' << counts[k] << ',' << csvEscape(row->source) << ',' << csvEscape(row->output) << "\n";
    }
}



bool isMultiplayerFastFileSource(const std::string& source)
{
    std::string s = source;
    std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c){ return static_cast<char>(std::tolower(c)); });

    // Multiplayer map zones and the standard MP shared/support zones.
    if (s.rfind("mp_", 0) == 0) return true;
    if (s.rfind("common_mp", 0) == 0) return true;
    if (s.rfind("code_post_gfx_mp", 0) == 0) return true;
    if (s.rfind("localized_code_post_gfx_mp", 0) == 0) return true;
    if (s.rfind("localized_common_mp", 0) == 0) return true;
    if (s.rfind("patch_mp", 0) == 0) return true;
    if (s.rfind("ui_mp", 0) == 0) return true;
    if (s.find("nx1mp") != std::string::npos) return true;

    return false;
}



void writeCategorizedWeaponLibrary(const fs::path& root,
                                   const std::vector<ManifestRow>& rows,
                                   bool multiplayerOnly,
                                   const std::string& folderName,
                                   const std::string& csvName)
{
    const fs::path weaponRoot = root / folderName;
    fs::create_directories(weaponRoot);

    std::ofstream index(root / csvName);
    index << "weapon,name,match_type,confidence,source,format,width,height,data_crc32,library_output,original_output\n";

    std::map<std::tuple<std::string,std::string,int,int,std::uint32_t>, fs::path> copied;
    std::map<std::string, std::size_t> weaponCounts;
    std::size_t matchedRows = 0;
    std::size_t copiedCount = 0;

    for (const auto& r : rows)
    {
        if (r.status != "ok" || r.output.empty()) continue;
        if (multiplayerOnly && !isMultiplayerFastFileSource(r.source)) continue;

        const WeaponDetection d = detectWeaponTexture(r.name);
        if (!d.accepted) continue;
        ++matchedRows;

        const std::string weapon = d.weapon.empty() ? "UNKNOWN_WEAPON" : d.weapon;
        const auto key = std::make_tuple(weapon, r.format, r.width, r.height, r.dataCrc32);

        fs::path libRel;
        auto it = copied.find(key);
        if (it == copied.end())
        {
            const fs::path gunDir = weaponRoot / sanitizeFileName(weapon);
            fs::create_directories(gunDir);

            std::string base = sanitizeFileName(r.name) + ".dds";
            fs::path dest = gunDir / base;
            int suffix = 2;
            while (fs::exists(dest))
                dest = gunDir / (sanitizeFileName(r.name) + "_" + std::to_string(suffix++) + ".dds");

            const fs::path original = root / fs::path(r.output);
            std::error_code ec;
            fs::copy_file(original, dest, fs::copy_options::overwrite_existing, ec);
            if (!ec)
            {
                libRel = fs::relative(dest, root);
                copied[key] = libRel;
                ++copiedCount;
                ++weaponCounts[weapon];
            }
        }
        else
        {
            libRel = it->second;
        }

        if (!libRel.empty())
        {
            index << csvEscape(weapon) << ',' << csvEscape(r.name) << ','
                  << csvEscape(d.matchType) << ',' << csvEscape(d.confidence) << ','
                  << csvEscape(r.source) << ',' << csvEscape(r.format) << ','
                  << r.width << ',' << r.height << ",0x"
                  << std::hex << std::setw(8) << std::setfill('0') << r.dataCrc32
                  << std::dec << std::setfill(' ') << ','
                  << csvEscape(libRel.generic_string()) << ',' << csvEscape(r.output) << "\n";
        }
    }

    std::ofstream summary(weaponRoot / "README.txt");
    summary << "NX1ImagePuller v0.6.0 categorized weapon texture library\n"
            << "Filter mode: strict/high-confidence weapon materials only.\n"
            << "Matched weapon image rows: " << matchedRows << "\n"
            << "Unique weapon texture files copied: " << copiedCount << "\n\n"
            << "Textures are grouped into one folder per detected weapon.\n"
            << "SHARED_ATTACHMENTS contains weapon attachments that cannot be tied to one gun safely.\n"
            << "UNKNOWN_WEAPON is used only for explicit weapon assets whose model name cannot be parsed.\n\n"
            << "Weapon folders:\n";
    for (const auto& kv : weaponCounts)
        summary << "  " << kv.first << ": " << kv.second << "\n";
}

void writeWeaponLibrary(const fs::path& root, const std::vector<ManifestRow>& rows)
{
    writeCategorizedWeaponLibrary(root, rows, false,
                                  "WEAPONS_BY_GUN",
                                  "weapon_textures_by_gun.csv");
}

void writeMultiplayerWeaponLibrary(const fs::path& root, const std::vector<ManifestRow>& rows)
{
    writeCategorizedWeaponLibrary(root, rows, true,
                                  "MULTIPLAYER_WEAPONS_BY_GUN",
                                  "multiplayer_weapon_textures_by_gun.csv");
}


std::vector<fs::path> collectInputs(const fs::path& input)
{
    std::vector<fs::path> files;
    if (fs::is_regular_file(input))
    {
        files.push_back(input);
        return files;
    }
    if (!fs::is_directory(input)) throw std::runtime_error("input path is not a file or directory");

    for (const auto& e : fs::recursive_directory_iterator(input, fs::directory_options::skip_permission_denied))
    {
        if (!e.is_regular_file()) continue;
        auto ext = e.path().extension().string();
        std::transform(ext.begin(), ext.end(), ext.begin(), [](unsigned char c){ return static_cast<char>(std::tolower(c)); });
        if (ext == ".ff" || ext == ".ffm") files.push_back(e.path());
    }
    std::sort(files.begin(), files.end());
    return files;
}


std::string lowerCopy(std::string s)
{
    std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c){ return static_cast<char>(std::tolower(c)); });
    return s;
}

bool isFastFilePath(const fs::path& p)
{
    auto ext = lowerCopy(p.extension().string());
    return ext == ".ff" || ext == ".ffm";
}

std::string mapKeyForPath(const fs::path& p)
{
    std::string stem = lowerCopy(p.stem().string());
    if (!(stem.rfind("mp_", 0) == 0 || stem.rfind("nx_", 0) == 0)) return {};
    const std::string loadSuffix = "_load";
    if (stem.size() > loadSuffix.size() &&
        stem.compare(stem.size() - loadSuffix.size(), loadSuffix.size(), loadSuffix) == 0)
    {
        stem.resize(stem.size() - loadSuffix.size());
    }
    return stem;
}

std::map<std::string, std::vector<fs::path>> collectMapGroups(const fs::path& root, bool multiplayerOnly)
{
    if (!fs::is_directory(root)) throw std::runtime_error("game folder is not a directory");

    std::map<std::string, std::vector<fs::path>> groups;
    for (const auto& e : fs::recursive_directory_iterator(root, fs::directory_options::skip_permission_denied))
    {
        if (!e.is_regular_file() || !isFastFilePath(e.path())) continue;
        const std::string key = mapKeyForPath(e.path());
        if (key.empty()) continue;
        if (multiplayerOnly && key.rfind("mp_", 0) != 0) continue;
        groups[key].push_back(e.path());
    }

    for (auto& kv : groups)
    {
        std::sort(kv.second.begin(), kv.second.end(), [](const fs::path& a, const fs::path& b)
        {
            const auto as = lowerCopy(a.stem().string());
            const auto bs = lowerCopy(b.stem().string());
            const bool aLoad = as.size() >= 5 && as.compare(as.size() - 5, 5, "_load") == 0;
            const bool bLoad = bs.size() >= 5 && bs.compare(bs.size() - 5, 5, "_load") == 0;
            if (aLoad != bLoad) return !aLoad; // main FastFile first
            return a.string() < b.string();
        });
    }
    return groups;
}

struct ExtractionSummary
{
    std::size_t images = 0;
    std::size_t failedFiles = 0;
    std::vector<ManifestRow> rows;
};

ExtractionSummary extractFileSet(const std::vector<fs::path>& inputs, const fs::path& output)
{
    fs::create_directories(output);
    ExtractionSummary result;

    for (std::size_t i = 0; i < inputs.size(); ++i)
    {
        const auto& p = inputs[i];
        std::cout << "  [" << (i + 1) << "/" << inputs.size() << "] " << p.string() << "\n";
        try
        {
            auto rows = processFastFile(p, output, true);
            result.images += static_cast<std::size_t>(
                std::count_if(rows.begin(), rows.end(), [](const ManifestRow& r){ return r.status == "ok"; }));
            result.rows.insert(result.rows.end(),
                               std::make_move_iterator(rows.begin()),
                               std::make_move_iterator(rows.end()));
        }
        catch (const std::exception& e)
        {
            ++result.failedFiles;
            std::cerr << "    SKIP: " << e.what() << "\n";
        }
    }
    return result;
}

void finalizeMapOutput(const fs::path& output, const std::vector<ManifestRow>& rows)
{
    writeManifest(output, rows);
    writeUniqueManifest(output, rows);
}

int runAllMapMode(const fs::path& gameRoot, const fs::path& outputRoot, bool multiplayerOnly)
{
    const auto groups = collectMapGroups(gameRoot, multiplayerOnly);
    if (groups.empty()) throw std::runtime_error("no map FastFiles were found");

    fs::create_directories(outputRoot);
    std::ofstream index(outputRoot / "maps.csv");
    index << "map,fastfiles,images,failed_files,output_folder\n";

    std::size_t mapNumber = 0;
    std::size_t totalImages = 0;
    std::size_t totalFailed = 0;

    std::cout << "NX1ImagePuller v0.6.0 - "
              << (multiplayerOnly ? "ALL MULTIPLAYER MAPS" : "ALL MAPS") << "\n";
    std::cout << "Found " << groups.size() << " map(s).\n";
    std::cout << "Output root: " << fs::absolute(outputRoot).string() << "\n\n";

    for (const auto& kv : groups)
    {
        ++mapNumber;
        const fs::path mapOut = outputRoot / kv.first;
        std::cout << "============================================================\n";
        std::cout << "MAP [" << mapNumber << "/" << groups.size() << "]: " << kv.first << "\n";
        std::cout << "FastFiles: " << kv.second.size() << "\n";
        std::cout << "Output: " << mapOut.string() << "\n";

        auto result = extractFileSet(kv.second, mapOut);
        finalizeMapOutput(mapOut, result.rows);

        totalImages += result.images;
        totalFailed += result.failedFiles;
        index << csvEscape(kv.first) << ',' << kv.second.size() << ','
              << result.images << ',' << result.failedFiles << ','
              << csvEscape(fs::relative(mapOut, outputRoot).generic_string()) << "\n";

        std::cout << "  Map images exported: " << result.images << "\n";
        std::cout << "  Map FastFiles failed: " << result.failedFiles << "\n\n";
    }

    std::cout << "============================================================\n";
    std::cout << "ALL MAP EXTRACTION COMPLETE\n";
    std::cout << "  Maps processed: " << groups.size() << "\n";
    std::cout << "  Images exported: " << totalImages << "\n";
    std::cout << "  FastFiles failed: " << totalFailed << "\n";
    std::cout << "  Map index: " << (outputRoot / "maps.csv").string() << "\n";
    return totalFailed == 0 ? 0 : 3;
}

int runOneMapMode(const std::string& requested, const fs::path& gameRoot, const fs::path& outputRoot)
{
    const auto groups = collectMapGroups(gameRoot, false);
    if (groups.empty()) throw std::runtime_error("no map FastFiles were found");

    const std::string wanted = lowerCopy(requested);
    auto exact = groups.find(wanted);
    std::vector<std::string> matches;
    if (exact != groups.end())
    {
        matches.push_back(exact->first);
    }
    else
    {
        for (const auto& kv : groups)
        {
            if (kv.first.find(wanted) != std::string::npos) matches.push_back(kv.first);
        }
    }

    if (matches.empty())
        throw std::runtime_error("map not found: " + requested);
    if (matches.size() > 1)
    {
        std::ostringstream oss;
        oss << "map name is ambiguous: " << requested << ". Matches:";
        for (const auto& m : matches) oss << " " << m;
        throw std::runtime_error(oss.str());
    }

    const std::string& key = matches.front();
    const auto& files = groups.at(key);
    const fs::path mapOut = outputRoot / key;

    std::cout << "NX1ImagePuller v0.6.0 - SINGLE MAP\n";
    std::cout << "Map: " << key << "\n";
    std::cout << "FastFiles: " << files.size() << "\n";
    std::cout << "Output: " << fs::absolute(mapOut).string() << "\n\n";

    auto result = extractFileSet(files, mapOut);
    finalizeMapOutput(mapOut, result.rows);

    std::cout << "\nDone.\n";
    std::cout << "  Map images exported: " << result.images << "\n";
    std::cout << "  Map FastFiles failed: " << result.failedFiles << "\n";
    std::cout << "  Manifest: " << (mapOut / "images.csv").string() << "\n";
    std::cout << "  Unique index: " << (mapOut / "unique_images.csv").string() << "\n";
    return result.failedFiles == 0 ? 0 : 3;
}

void usage(const char* exe)
{
    std::cout << "NX1ImagePuller v0.6.0\n\n"
              << "Direct, read-only NX1 FastFile image extractor. No Xenia memory dump is required.\n\n"
              << "Normal/full-game mode:\n"
              << "  " << exe << " <NX1 game folder | one .ff/.ffm> [output folder]\n\n"
              << "Map modes:\n"
              << "  " << exe << " --all-mp-maps <NX1 game folder> [output root]\n"
              << "  " << exe << " --all-maps <NX1 game folder> [output root]\n"
              << "  " << exe << " --map <map name> <NX1 game folder> [output root]\n"
              << "  " << exe << " --list-mp-maps <NX1 game folder>\n"
              << "  " << exe << " --list-maps <NX1 game folder>\n\n"
              << "Examples:\n"
              << "  " << exe << " --all-mp-maps \"<NX1_GAME_FOLDER>\" \"<OUTPUT_FOLDER>\"\n"
              << "  " << exe << " --map meteor \"<NX1_GAME_FOLDER>\" \"<OUTPUT_FOLDER>\"\n\n"
              << "The input files are never modified.\n";
}
}

int main(int argc, char** argv)
{
    if (argc < 2)
    {
        usage(argv[0]);
        return 1;
    }

    try
    {
        const std::string mode = argv[1];

        if (mode == "--list-mp-maps" || mode == "--list-maps")
        {
            if (argc < 3) throw std::runtime_error("game folder is required");
            const bool mpOnly = mode == "--list-mp-maps";
            const auto groups = collectMapGroups(fs::path(argv[2]), mpOnly);
            for (const auto& kv : groups) std::cout << kv.first << "\n";
            return 0;
        }

        if (mode == "--all-mp-maps" || mode == "--all-maps")
        {
            if (argc < 3) throw std::runtime_error("game folder is required");
            const fs::path gameRoot = argv[2];
            const fs::path outputRoot = argc >= 4 ? fs::path(argv[3]) : fs::path("NX1_Map_Assets");
            return runAllMapMode(gameRoot, outputRoot, mode == "--all-mp-maps");
        }

        if (mode == "--map")
        {
            if (argc < 4) throw std::runtime_error("usage: --map <map name> <game folder> [output root]");
            const std::string mapName = argv[2];
            const fs::path gameRoot = argv[3];
            const fs::path outputRoot = argc >= 5 ? fs::path(argv[4]) : fs::path("NX1_Map_Assets");
            return runOneMapMode(mapName, gameRoot, outputRoot);
        }

        const fs::path input = argv[1];
        const fs::path output = argc >= 3 ? fs::path(argv[2]) : fs::path("NX1_Images");
        const auto inputs = collectInputs(input);
        if (inputs.empty()) throw std::runtime_error("no .ff or .ffm files found");

        std::cout << "NX1ImagePuller v0.6.0\n";
        std::cout << "Found " << inputs.size() << " FastFile(s).\n";
        std::cout << "Output: " << fs::absolute(output).string() << "\n\n";

        std::vector<ManifestRow> allRows;
        std::size_t ok = 0;
        std::size_t failedFiles = 0;
        for (std::size_t i = 0; i < inputs.size(); ++i)
        {
            const auto& p = inputs[i];
            std::cout << "[" << (i + 1) << "/" << inputs.size() << "] " << p.string() << "\n";
            try
            {
                auto rows = processFastFile(p, output, true);
                ok += static_cast<std::size_t>(std::count_if(rows.begin(), rows.end(), [](const ManifestRow& r){ return r.status == "ok"; }));
                allRows.insert(allRows.end(), std::make_move_iterator(rows.begin()), std::make_move_iterator(rows.end()));
            }
            catch (const std::exception& e)
            {
                ++failedFiles;
                std::cerr << "  SKIP: " << e.what() << "\n";
            }
        }

        writeManifest(output, allRows);
        writeUniqueManifest(output, allRows);
        writeWeaponLibrary(output, allRows);
        writeMultiplayerWeaponLibrary(output, allRows);
        std::cout << "\nDone.\n";
        std::cout << "  Images exported: " << ok << "\n";
        std::cout << "  FastFiles skipped/failed: " << failedFiles << "\n";
        std::cout << "  Manifest: " << (output / "images.csv").string() << "\n";
        std::cout << "  Unique index: " << (output / "unique_images.csv").string() << "\n";
        std::cout << "  Weapon library: " << (output / "WEAPONS_BY_GUN").string() << "\n";
        std::cout << "  Weapon index: " << (output / "weapon_textures_by_gun.csv").string() << "\n";
        std::cout << "  MP weapon library: " << (output / "MULTIPLAYER_WEAPONS_BY_GUN").string() << "\n";
        std::cout << "  MP weapon index: " << (output / "multiplayer_weapon_textures_by_gun.csv").string() << "\n";
        return 0;
    }
    catch (const std::exception& e)
    {
        std::cerr << "ERROR: " << e.what() << "\n";
        return 2;
    }
}
