@echo off
setlocal EnableExtensions
cd /d "%~dp0"

title NX1ImagePuller Portable Windows Builder

echo ============================================================
echo          NX1ImagePuller v0.5.0 Windows Builder
echo ============================================================
echo.
echo Project folder: %CD%
echo.

set "VSWHERE="
set "VSINSTALL="
set "CMAKE_EXE="
set "VCPKG_ROOT_FOUND="

rem ------------------------------------------------------------
rem 1) Find vswhere / Visual Studio, regardless of install drive.
rem ------------------------------------------------------------
for %%P in (
  "%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
  "%ProgramFiles%\Microsoft Visual Studio\Installer\vswhere.exe"
) do (
  if exist "%%~P" set "VSWHERE=%%~P"
)

if not defined VSWHERE (
  for /f "delims=" %%P in ('where vswhere.exe 2^>nul') do (
    if not defined VSWHERE set "VSWHERE=%%P"
  )
)

if defined VSWHERE (
  for /f "usebackq tokens=*" %%I in (`"%VSWHERE%" -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath`) do (
    if not defined VSINSTALL set "VSINSTALL=%%I"
  )
)

if defined VSINSTALL (
  echo Found Visual Studio:
  echo   %VSINSTALL%
  echo.
  if exist "%VSINSTALL%\Common7\Tools\VsDevCmd.bat" (
    call "%VSINSTALL%\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64 >nul
  )
)

rem ------------------------------------------------------------
rem 2) Find CMake: PATH first, then Visual Studio's bundled copy.
rem ------------------------------------------------------------
for /f "delims=" %%P in ('where cmake.exe 2^>nul') do (
  if not defined CMAKE_EXE set "CMAKE_EXE=%%P"
)

if not defined CMAKE_EXE if defined VSINSTALL (
  if exist "%VSINSTALL%\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\cmake.exe" (
    set "CMAKE_EXE=%VSINSTALL%\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\cmake.exe"
  )
)

if not defined CMAKE_EXE (
  echo ============================================================
  echo ERROR: CMake was not found.
  echo ============================================================
  echo.
  echo Open Visual Studio Installer ^> Modify and install:
  echo   - Desktop development with C++
  echo   - C++ CMake tools for Windows
  echo   - Windows 10 or Windows 11 SDK
  echo.
  pause
  exit /b 1
)

echo Found CMake:
echo   %CMAKE_EXE%
echo.

rem ------------------------------------------------------------
rem 3) Find vcpkg: environment, Visual Studio, then PATH.
rem ------------------------------------------------------------
if defined VCPKG_ROOT (
  if exist "%VCPKG_ROOT%\scripts\buildsystems\vcpkg.cmake" (
    set "VCPKG_ROOT_FOUND=%VCPKG_ROOT%"
  )
)

if not defined VCPKG_ROOT_FOUND if defined VSINSTALL (
  if exist "%VSINSTALL%\VC\vcpkg\scripts\buildsystems\vcpkg.cmake" (
    set "VCPKG_ROOT_FOUND=%VSINSTALL%\VC\vcpkg"
  )
)

if not defined VCPKG_ROOT_FOUND (
  for /f "delims=" %%P in ('where vcpkg.exe 2^>nul') do (
    if not defined VCPKG_ROOT_FOUND (
      for %%D in ("%%~dpP.") do set "VCPKG_ROOT_FOUND=%%~fD"
    )
  )
)

if not defined VCPKG_ROOT_FOUND (
  echo ============================================================
  echo ERROR: vcpkg was not found.
  echo ============================================================
  echo.
  echo In Visual Studio Installer, add the vcpkg package manager
  echo component, or set VCPKG_ROOT to your vcpkg folder.
  echo.
  pause
  exit /b 1
)

echo Found vcpkg:
echo   %VCPKG_ROOT_FOUND%
echo.

set "BUILD_DIR=build-win"
set "TOOLCHAIN=%VCPKG_ROOT_FOUND%\scripts\buildsystems\vcpkg.cmake"

echo [1/2] Configuring...
"%CMAKE_EXE%" -S . -B "%BUILD_DIR%" -A x64 ^
  -DCMAKE_TOOLCHAIN_FILE="%TOOLCHAIN%" ^
  -DVCPKG_TARGET_TRIPLET=x64-windows-static

if errorlevel 1 (
  echo.
  echo ============================================================
  echo ERROR: CMake configuration failed.
  echo ============================================================
  echo.
  pause
  exit /b 1
)

echo.
echo [2/2] Building Release...
"%CMAKE_EXE%" --build "%BUILD_DIR%" --config Release

if errorlevel 1 (
  echo.
  echo ============================================================
  echo ERROR: Compilation failed.
  echo ============================================================
  echo.
  pause
  exit /b 1
)

echo.
echo ============================================================
echo BUILD COMPLETE
echo ============================================================
echo EXE: %CD%\%BUILD_DIR%\Release\NX1ImagePuller.exe
echo.
echo You can now double-click NX1_ASSET_MENU.bat.
echo.
pause
endlocal
