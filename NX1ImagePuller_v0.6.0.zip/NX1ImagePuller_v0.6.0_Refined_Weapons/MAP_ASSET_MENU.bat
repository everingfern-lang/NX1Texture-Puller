@echo off
call "%~dp0NX1_ASSET_MENU.bat"
